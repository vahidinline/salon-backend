const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();
const path = require('path');
const uploadRouter = require('./routes/upload');
const authRoutes = require('./routes/authRoutes');
const salonRoutes = require('./routes/salonRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const serviceRoutes = require('./routes/serviceRoutes');
const availabilityRoutes = require('./routes/availabilityRoutes');
const clientAuth = require('./routes/clientAuth.route');
const Client = require('./routes/ClientsRoute');
const AllAvailabilities = require('./routes/AllAvailibilities');
const Booking = require('./models/Booking');
const cron = require('node-cron');
const app = express();
app.use(express.json());
app.use(cors());

app.get('/', (req, res) => res.send('updated: Oct 08 2025'));
app.get('/health', (req, res) => res.status(200).send('OK'));

app.use('/auth', authRoutes);
app.use('/salons', salonRoutes);
app.use('/client-auth', clientAuth);
app.use('/salons/:salonId/employees', employeeRoutes);
app.use('/salons/:salonId/clients', Client);
app.use('/salons/:salonId/services', serviceRoutes);
app.use('/salons/:salonId/bookings', require('./routes/Booking'));
app.use('/salons/:salonId/availability', availabilityRoutes);
app.use('/availabilities', AllAvailabilities);
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
app.use('/upload', uploadRouter);
const uri = process.env.MONGO_URI;
const PORT = process.env.PORT || 5001;

mongoose
  .connect(uri)
  .then(() => {
    console.log('✅ Connected to MongoDB Atlas');
    app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
  })
  .catch((err) => console.error('❌ MongoDB connection error:', err));

cron.schedule('*/10 * * * *', async () => {
  try {
    const now = new Date();
    console.log('Running auto-cancel cron job at', now);
    const result = await Booking.updateMany(
      {
        status: 'pending',
        paymentDeadline: { $lt: now },
      },
      {
        $set: {
          status: 'cancelled',
          cancelationReason: 'unPaid',
          cancelationDate: now,
        },
      }
    );

    if (result.modifiedCount > 0) {
      console.log(`⏰ Auto-cancelled ${result.modifiedCount} unpaid bookings.`);
    } else {
      console.log('⏰ No unpaid bookings to auto-cancel at this time.');
    }
  } catch (err) {
    console.error('Error in auto-cancel cron job:', err);
  }
});
